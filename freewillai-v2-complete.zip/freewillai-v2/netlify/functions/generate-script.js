exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };

  const { topic, platform, length, tone, hookStyle } = JSON.parse(event.body || '{}');

  if (!topic) return { statusCode: 400, body: JSON.stringify({ error: 'Topic required' }) };

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{
          role: 'user',
          content: `You are a viral content creator expert. Write a ${length} video script for ${platform}.

Topic: "${topic}"
Tone: ${tone}
Hook Style: ${hookStyle}

Rules:
- Hook must stop the scroll in under 3 seconds
- Naturally include a monetization CTA (affiliate, course, or product)  
- Optimize for ${platform} algorithm
- Make it feel human, not AI-generated

Respond ONLY with raw JSON (no markdown, no backticks, no explanation):
{"hook":"...","body":"...","cta":"...","hashtags":["...","...","...","...","..."]}`
        }]
      })
    });

    const data = await response.json();
    const raw = data.content?.[0]?.text || '{}';
    
    let parsed;
    try { parsed = JSON.parse(raw); }
    catch {
      parsed = {
        hook: `You won't believe what happened when I tried ${topic}...`,
        body: `Most people completely overlook this about ${topic}. Here's the truth that nobody talks about — and it's costing you money every single day you don't know it.`,
        cta: `Follow for more. Link in bio for the exact resource I use — it's changed everything.`,
        hashtags: ['#viral', '#trending', '#money', '#ai', '#success']
      };
    }

    return {
      statusCode: 200,
      headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' },
      body: JSON.stringify(parsed)
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: err.message })
    };
  }
};
