const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

exports.handler = async (event) => {
  const sig = event.headers['stripe-signature'];
  let stripeEvent;

  try {
    stripeEvent = stripe.webhooks.constructEvent(
      event.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    return { statusCode: 400, body: `Webhook Error: ${err.message}` };
  }

  // Handle events
  switch (stripeEvent.type) {
    case 'checkout.session.completed': {
      const session = stripeEvent.data.object;
      console.log(`✅ Payment success: ${session.customer_email} - $${session.amount_total / 100}`);
      // TODO: save to Supabase — user email + plan + subscription_id
      break;
    }
    case 'customer.subscription.deleted': {
      const sub = stripeEvent.data.object;
      console.log(`❌ Subscription cancelled: ${sub.customer}`);
      // TODO: revoke access in Supabase
      break;
    }
    case 'invoice.payment_failed': {
      const invoice = stripeEvent.data.object;
      console.log(`⚠️ Payment failed: ${invoice.customer_email}`);
      // TODO: send dunning email
      break;
    }
    case 'customer.subscription.updated': {
      const sub = stripeEvent.data.object;
      console.log(`🔄 Subscription updated: ${sub.customer} → ${sub.status}`);
      break;
    }
  }

  return { statusCode: 200, body: JSON.stringify({ received: true }) };
};
