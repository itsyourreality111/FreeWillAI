exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };

  const { email } = JSON.parse(event.body || '{}');
  if (!email) return { statusCode: 400, body: JSON.stringify({ error: 'Email required' }) };

  try {
    const response = await fetch(`${process.env.SUPABASE_URL}/auth/v1/magiclink`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': process.env.SUPABASE_ANON_KEY
      },
      body: JSON.stringify({ email })
    });

    if (!response.ok) throw new Error('Supabase auth failed');

    return {
      statusCode: 200,
      headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' },
      body: JSON.stringify({ success: true, message: 'Magic link sent to ' + email })
    };
  } catch (err) {
    // Fallback: log and confirm (prevents email enumeration)
    console.log('Auth attempt for:', email);
    return {
      statusCode: 200,
      headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' },
      body: JSON.stringify({ success: true, message: 'If this email exists, a link was sent.' })
    };
  }
};
