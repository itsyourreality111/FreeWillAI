const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };

  const { priceId, mode, email } = JSON.parse(event.body || '{}');
  const origin = event.headers.origin || 'https://valkrastudio.netlify.app';

  try {
    const sessionConfig = {
      payment_method_types: ['card', 'paypal'],
      customer_email: email || undefined,
      line_items: [{ price: priceId, quantity: 1 }],
      mode: mode || 'subscription', // 'subscription' or 'payment'
      success_url: `${origin}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/pricing.html`,
      allow_promotion_codes: true,
      billing_address_collection: 'auto',
      metadata: { app: 'valkra-studio' }
    };

    // Enable Google Pay / Apple Pay via payment_method_types
    if (mode !== 'payment') {
      sessionConfig.payment_method_types = ['card', 'paypal'];
    }

    const session = await stripe.checkout.sessions.create(sessionConfig);
    return {
      statusCode: 200,
      headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: session.url })
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: err.message })
    };
  }
};
